/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.uni.parcial_auqui.pruebas;

import java.sql.Connection;
import pe.edu.uni.parcial_auqui.AccesoBD.AccesoBD;

/**
 *
 * @author LENOVO
 */
public class Prueba01 {
    public static void main(String[] args) {
		
		try {
			Connection cn = AccesoBD.getConnection();
			System.out.println("Ok");
			cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
