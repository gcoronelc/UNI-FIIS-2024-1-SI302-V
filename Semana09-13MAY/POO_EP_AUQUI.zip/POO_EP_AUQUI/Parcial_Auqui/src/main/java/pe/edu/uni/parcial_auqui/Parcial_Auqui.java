/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pe.edu.uni.parcial_auqui;

/**
 *
 * @author LENOVO
 */
public class Parcial_Auqui {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
